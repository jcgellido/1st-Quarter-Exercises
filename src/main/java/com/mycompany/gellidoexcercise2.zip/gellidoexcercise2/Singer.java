/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gellidoexcercise2;

/**
 *
 * @author Jhoenica C. Gellido
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    Song favoriteSong;
    Management handler;
    int handlerconcerts;
    
    public Singer(String name, int noOfPerformances, double earnings, Song favoriteSong, Management handler) {
        this.name = name;
        this.noOfPerformances = noOfPerformances;
        this.earnings = earnings;
        this.favoriteSong = favoriteSong;
        this.handler = handler;
        this.handlerconcerts = 0;
    }
    
    public void performForAudience(int audience){
        this.noOfPerformances += 1;
        this.earnings += audience*100;
        double cut = audience*100*this.handler.percentage;
        this.earnings-=cut;
        this.handler.revenue+=cut;
        this.handlerconcerts+=1;
        this.handler.concertsdone += 1;
        System.out.println(this.name + " performed for an audience of " + audience);
        
    }
    
    public void changeFaveSong(Song newFavoriteSong) {
        this.favoriteSong = newFavoriteSong;
    }
    public void changelabel(Management newhandler){
        this.handler = newhandler;
        this.handlerconcerts = 0; /*goes back to 0 after change*/
    }
    
    public void introduce() {
        System.out.println("Hi! My name is " + this.name + " and I am managed by " + this.handler.name);
    }
}
