/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gellidoexcercise2;

/**
 *
 * @author Jhoenica C. Gellido
 */
public class Management {
    String name;
    double percentage;
    double revenue;
    int concertsdone;
    
    public Management(String name,double percentage, double revenue, int concertsdone) {
        this.name = name;
        this.percentage = percentage;
        this.revenue = revenue;
        this.concertsdone = concertsdone;
    }
}
