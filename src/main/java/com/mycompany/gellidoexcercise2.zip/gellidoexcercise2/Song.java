/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gellidoexcercise2;

/**
 *
 * @author Jhoenica C. Gellido
 */
public class Song {
    String title;
    String artist;
    
    public Song(String title, String artist){
        this.title = title;
        this.artist = artist;
    }
    public Song(String title) {
        this.title = title;
        this.artist = "Unknown";
    }
}
