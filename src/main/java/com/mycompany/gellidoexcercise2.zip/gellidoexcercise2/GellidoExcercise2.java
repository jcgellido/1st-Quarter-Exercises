/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gellidoexcercise2;

/**
 *
 * @author Jhoenica C. Gellido
 */
public class GellidoExcercise2 {

    public static void main(String[] args) {
        Management Alist = new Management("The A-list", 0.2, 500000, 14);
        Management star = new Management("Starhouse Entertainment", 0.15, 200000, 6);
        Song toolate = new Song("It's too late", "Carole King");
        Singer oliviarhodes = new Singer("Olivia Rhodes", 12, 0, toolate, star);
        System.out.println(Alist.name + " has " + Alist.revenue + " total revenue");
        System.out.println(Alist.name + " has handled " + Alist.concertsdone + " concerts so far.");
        System.out.println(star.name + " has handled " + star.concertsdone + " concerts so far.");
        Song onlyone = new Song("Only One", "Carlie Hanson");
        Singer taysmith = new Singer("Taye Smith", 50, 0, onlyone, Alist);
        System.out.println(taysmith.name + "'s favorite song is " + taysmith.favoriteSong.title + " by " + taysmith.favoriteSong.artist);
        taysmith.introduce();
        taysmith.performForAudience(12);
        System.out.println("Taye Smith has " + taysmith.earnings + " in earnings");
        Song westcoast = new Song("West Coast", "Junior Empire");
        taysmith.changeFaveSong(westcoast);
        System.out.println(taysmith.name + "'s favorite song is " + taysmith.favoriteSong.title + " by " + taysmith.favoriteSong.artist);
        System.out.println("After the mini performance, " + taysmith.handler.name + " has " + Alist.revenue + "now");
        taysmith.performForAudience(10000);
        System.out.println("Wow, looks like someone got richer!" + taysmith.name + "'s earnings soared up to " + taysmith.earnings + " after performing");
        System.out.println(Alist.name + " found an artist to keep, they now have " + Alist.revenue + " in total");
        oliviarhodes.introduce();
        System.out.println(oliviarhodes.name + "'s favorite song is " + oliviarhodes.favoriteSong.title);
        oliviarhodes.performForAudience(500);
        System.out.println(oliviarhodes.name + " is now " + oliviarhodes.earnings + " worth. " + star.name + " has " + star.revenue + " in total revenue.");
        System.out.println(Alist.name + " has handled " + Alist.concertsdone + " concerts so far.");
        System.out.println(star.name + " has handled " + star.concertsdone + " concerts so far.");
    }
}
